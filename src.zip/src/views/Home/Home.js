// @ is an alias to /src
import Banner from '@/components/Banner/Banner.vue'
// import {mapState} from 'vuex'
import './mock.js'

export default {
  name: 'Home',
  components: {
    Banner
  }
  // computed: mapState([
  //   'autoEnrollRequested'
  // ])
 
  
}