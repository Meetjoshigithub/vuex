<template>
  <div class="home container">
    <p class="textprimary">We email your order receipt to example@gmail.com</p>
    <Banner/>
  </div>
</template>
<script src="./Home.js"></script>
<style src="./Home.css"></style>